#include "imgui/imgui.h"
#include "imgui/imgui-SFML.h"
#include "imnodes/imnodes.h"
#include <SFML/Graphics/CircleShape.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/System/Clock.hpp>
#include <SFML/Window/Event.hpp>

#include "editor.h"

int main() {

    sf::RenderWindow window(sf::VideoMode(800,600), "lambda");
    window.setFramerateLimit(60);

    ImGui::SFML::Init(window);
    ImNodes::CreateContext();

    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;

    sf::Clock deltaClock;
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            ImGui::SFML::ProcessEvent(window, event);

            if (event.type == sf::Event::Closed) {
                window.close();
            }

            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Delete or event.key.code == sf::Keyboard::BackSpace){
                    delete_selected();
                }
            }
        }



        ImGui::SFML::Update(window, deltaClock.restart());

        ImVec2 fullscreen_size = ImVec2(io.DisplaySize.x, io.DisplaySize.y);
        ImGui::SetNextWindowSize(fullscreen_size);
        ImGui::SetNextWindowPos(ImVec2(0, 0));

        ImGui::Begin("main", NULL, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse);
        ImGui::DockSpace(ImGui::GetID("main"), ImVec2(0, 0), ImGuiDockNodeFlags_None);

        ImGui::Begin("editor");
        run_editor();

        ImGui::End();
        ImGui::End();

        window.clear();
        ImGui::SFML::Render(window);
        window.display();
    }

    nodes.clear();
    ImNodes::DestroyContext();
    ImGui::SFML::Shutdown();

    return 0;
}
